<?php
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'augustoandro');
define('DB_PASSWORD', 'manjaro');
define('DB_DATABASE', 'groww_login');
$db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
?>